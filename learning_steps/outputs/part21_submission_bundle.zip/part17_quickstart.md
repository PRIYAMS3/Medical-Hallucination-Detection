# Part 17 Quickstart (CPU-Friendly)

## 1) Start lightweight API server

```bash
python learning_steps/part17_api_lite.py --host 127.0.0.1 --port 8008
```

## 2) Health check

```bash
curl http://127.0.0.1:8008/health
```

## 3) Predict (POST)

Send JSON body:

```json
{
  "mode": "ensemble",
  "features": {
    "having_IP_Address": -1,
    "URL_Length": 1,
    "Shortining_Service": 1,
    "having_At_Symbol": 1,
    "double_slash_redirecting": -1,
    "Prefix_Suffix": -1,
    "having_Sub_Domain": -1,
    "SSLfinal_State": -1,
    "Domain_registeration_length": -1,
    "Favicon": 1,
    "port": 1,
    "HTTPS_token": -1,
    "Request_URL": 1,
    "URL_of_Anchor": -1,
    "Links_in_tags": 1,
    "SFH": -1,
    "Submitting_to_email": -1,
    "Abnormal_URL": -1,
    "Redirect": 0,
    "on_mouseover": 1,
    "RightClick": 1,
    "popUpWidnow": 1,
    "Iframe": 1,
    "age_of_domain": -1,
    "DNSRecord": -1,
    "web_traffic": -1,
    "Page_Rank": -1,
    "Google_Index": 1,
    "Links_pointing_to_page": 1,
    "Statistical_report": -1
  }
}
```

To use hybrid mode, set `"mode": "hybrid"`.

## 4) Runtime expectation on CPU

- Server startup: usually a few seconds
- Single prediction latency: typically under one second
- No retraining needed in this step
